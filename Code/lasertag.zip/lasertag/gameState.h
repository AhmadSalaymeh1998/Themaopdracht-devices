#ifndef GAMESTATE_H
#define GAMESTATE_H

enum class gameState {idle, startGame, runGame, hit, gameOver};  

#endif