#ifndef SENDIRMESSAGECONTROL_H
#define SENDIRMESSAGECONTROL_H


#include "pause_detector.h"
#include "message_decoder.h"


#endif
